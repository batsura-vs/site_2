from PIL import Image, ImageDraw

width = int(input('width: '))
height = int(input('height: '))
im = Image.new('RGB', (width, height), (100, 200, 255))
dr = ImageDraw.Draw(im)
w, h = im.size
one_h = h // 100
one_w = w // 100
dr.ellipse((w - one_w * 20, -one_h * 20, w + one_w * 20, one_h * 20), (255, 255, 0))
dr.rectangle(((0, h - one_h * 20), (w, h)), 'green')
dr.polygon(((one_w * 25, h),
            (one_w * 25, one_h * 50),
            (one_w * 50, one_h * 30),
            (one_w * 75, one_h * 50),
            (one_w * 75, h)), 'brown')
dr.rectangle(((one_w * 50 - one_w * 10, one_h * 75 - one_h * 10),
              (one_w * 50 + one_w * 10, one_h * 75 + one_h * 10)), (125, 225, 255))
im.save('house.png')
