from PIL import Image, ImageDraw

width = int(input('width: '))
height = int(input('height: '))
im = Image.new('RGB', (width, height), (100, 200, 255))
dr = ImageDraw.Draw(im)
w, h = im.size
one_w = w // 100
one_h = h // 100
dr.ellipse((w - one_w * 20, -one_h * 20, w + one_w * 20, one_h * 20), (255, 255, 0))
dr.rectangle(((0, h - one_h * 20), (w, h)), (50, 100, 225))
dr.polygon((
    (one_w * 30, one_h * 85),
    (one_w * 25, one_h * 65),
    (one_w * 75, one_h * 65),
    (one_w * 70, one_h * 85)
),
    (115, 53, 15))
dr.polygon((
    (one_w * 49, one_h * 65),
    (one_w * 49, one_h * 30),
    (one_w * 51, one_h * 30),
    (one_w * 51, one_h * 65)
),
    (115, 53, 15))
dr.polygon((
    (one_w * 51, one_h * 30),
    (one_w * 67, one_h * 45),
    (one_w * 51, one_h * 60)
),
    (255, 255, 255))
im.save('парусник.png')
